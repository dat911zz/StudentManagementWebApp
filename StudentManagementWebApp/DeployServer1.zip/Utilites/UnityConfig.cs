﻿using Castle.Windsor;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace StudentManagementWebApp.Utilites
{
    public static class UnityConfig
    {
        public static void RegisterComponents()
        {
            var container = new WindsorContainer();


        }
    }
}