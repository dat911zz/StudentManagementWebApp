﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace StudentManagementWebApp.Models
{
    public enum Role
    {
        SUPERADMIN = 1,
        ADMIN = 2,
        USER = 3,
    }
}