﻿const { htmlimports } = require("modernizr");
var dateInput = document.getElementById("DayOfBirth");
document.getElementById('theDate').value = dateInput.getAttribute("value");